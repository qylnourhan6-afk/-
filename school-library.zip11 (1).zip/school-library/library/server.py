"""Server start-up."""
from http.server import ThreadingHTTPServer

from . import config
from .db import db, init_db, normalize, now_iso
from .handlers import Handler
from .security import hash_password


class LibraryServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def ensure_first_admin() -> None:
    """Create the first admin from SERVER settings if no admin exists yet.

    Credentials come from LIBRARY_ADMIN_USERNAME / LIBRARY_ADMIN_PASSWORD (see config.py);
    they are never part of any front-end file, and only a password hash is stored.
    """
    username, password = config.ADMIN_USERNAME, config.ADMIN_PASSWORD
    with db() as conn:
        if conn.execute("SELECT 1 FROM users WHERE role = 'admin' LIMIT 1").fetchone():
            return
        if conn.execute("SELECT 1 FROM users WHERE username_key = ?", (username.casefold(),)).fetchone():
            print(f"NOTE: no admin exists but username '{username}' is taken by a normal account. "
                  f"Set LIBRARY_ADMIN_USERNAME to another name.", flush=True)
            return
        conn.execute(
            "INSERT INTO users (full_name, username, username_key, password_hash, role, is_active, "
            "search_norm, created_at) VALUES (?, ?, ?, ?, 'admin', 1, ?, ?)",
            ("أمين المكتبة", username, username.casefold(), hash_password(password),
             normalize(f"أمين المكتبة {username}"), now_iso()),
        )
    bar = "=" * 66
    print(f"\n{bar}\n  First run: admin account created\n"
          f"  Username : {username}\n  Password : {password}\n{bar}", flush=True)
    if password == config.DEFAULT_ADMIN_PASSWORD:
        print("  WARNING: this is the well-known default password. Anyone who knows it can\n"
              "  manage the whole site. Before putting the site on the Internet, change it from\n"
              "  the dashboard (Account tab) or set LIBRARY_ADMIN_PASSWORD before the first run.\n"
              f"{bar}\n", flush=True)


def main() -> None:
    init_db()
    ensure_first_admin()
    server = LibraryServer((config.HOST, config.PORT), Handler)
    print(f"School Library running at http://{config.HOST}:{config.PORT}/  (dashboard: /admin/)", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
