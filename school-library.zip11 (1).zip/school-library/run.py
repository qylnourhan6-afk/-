#!/usr/bin/env python3
"""Start the School Library website:  python3 run.py"""
from library.server import main

if __name__ == "__main__":
    main()
