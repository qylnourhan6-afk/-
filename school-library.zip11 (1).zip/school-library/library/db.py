"""SQLite database layer: schema, connection helper and Arabic text normalisation."""
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from .config import DATA_DIR, DB_PATH

SCHEMA = """
-- One table for everybody; what an account may do is decided by `role`.
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name    TEXT NOT NULL DEFAULT '',
    second_name   TEXT NOT NULL DEFAULT '',
    third_name    TEXT NOT NULL DEFAULT '',
    full_name     TEXT NOT NULL,
    username      TEXT NOT NULL,
    username_key  TEXT NOT NULL UNIQUE,          -- casefolded username: uniqueness check
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    is_active     INTEGER NOT NULL DEFAULT 1,
    search_norm   TEXT NOT NULL DEFAULT '',
    created_at    TEXT NOT NULL,
    last_login    TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    csrf       TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);

-- Anonymous by design: no user id, no IP, no time of day. Only the text and the date.
CREATE TABLE IF NOT EXISTS complaints (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    message    TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'new',
    created_on TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS competitions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    conditions  TEXT NOT NULL DEFAULT '',
    event_date  TEXT,
    event_note  TEXT NOT NULL DEFAULT '',
    how_to_join TEXT NOT NULL DEFAULT '',
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS books (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    title_norm  TEXT NOT NULL,
    author      TEXT NOT NULL DEFAULT '',
    author_norm TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'required',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS book_requests (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    student_name TEXT NOT NULL,
    class_name   TEXT NOT NULL,
    book_title   TEXT NOT NULL,
    notes        TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'new',
    admin_note   TEXT NOT NULL DEFAULT '',
    search_norm  TEXT NOT NULL,
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_books_title ON books(title_norm);
CREATE INDEX IF NOT EXISTS idx_requests_status ON book_requests(status, created_at);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
"""

# Site copy only (not library data). The librarian can change all of it from the dashboard.
DEFAULT_SETTINGS = {
    "welcome_title": "أهلاً بك في مكتبة مدرستنا 📚",
    "welcome_subtitle": "عالم من المعرفة والثقافة والقراءة بين يديك",
    "announcement": "",
    "footer_text": "مكتبة المدرسة",
    "requests_open": "1",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db():
    """Transaction scope: commits on success, rolls back on error."""
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _drop_legacy_sessions(conn) -> None:
    """Old sessions pointed at the `admins` table; drop them (everyone signs in once more)."""
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(sessions)")}
    if "admin_id" in cols:
        conn.execute("DROP TABLE sessions")


def _migrate_legacy_admins(conn) -> None:
    """Move accounts from the old `admins` table into `users` (role = admin), keeping their passwords."""
    if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='admins'").fetchone():
        return
    for a in conn.execute("SELECT * FROM admins").fetchall():
        conn.execute(
            "INSERT OR IGNORE INTO users (full_name, username, username_key, password_hash, role, "
            "is_active, search_norm, created_at) VALUES (?, ?, ?, ?, 'admin', 1, ?, ?)",
            (a["username"], a["username"], a["username"].casefold(), a["password_hash"],
             normalize(a["username"]), a["created_at"]),
        )
    conn.execute("DROP TABLE admins")


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with db() as conn:
        conn.execute("PRAGMA journal_mode = WAL")
        _drop_legacy_sessions(conn)
        conn.executescript(SCHEMA)
        _migrate_legacy_admins(conn)
        for key, value in DEFAULT_SETTINGS.items():
            conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (key, value))


# ---- Arabic-friendly search -------------------------------------------------

_DIACRITICS = re.compile(r"[ؐ-ًؚ-ٰٟۖ-ۭـ]")
_CHAR_MAP = {
    "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا",
    "ى": "ي", "ئ": "ي", "ؤ": "و", "ة": "ه", "ک": "ك", "ی": "ي",
}
_CHAR_MAP.update({a: str(i) for i, a in enumerate("٠١٢٣٤٥٦٧٨٩")})
_CHAR_MAP.update({a: str(i) for i, a in enumerate("۰۱۲۳۴۵۶۷۸۹")})
_TRANSLATION = str.maketrans(_CHAR_MAP)


def normalize(text: str) -> str:
    """Lower-case, strip tashkeel/tatweel and unify common Arabic letter variants."""
    text = _DIACRITICS.sub("", text or "")
    text = text.translate(_TRANSLATION).lower()
    return re.sub(r"\s+", " ", text).strip()


def like_pattern(text: str) -> str:
    """Build a safe `%text%` pattern for use with `LIKE ? ESCAPE '\\'`."""
    escaped = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"
