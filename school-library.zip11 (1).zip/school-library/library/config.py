"""Central configuration. Everything can be overridden with environment variables."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = Path(os.environ.get("LIBRARY_DATA_DIR", BASE_DIR / "data"))
DB_PATH = DATA_DIR / "library.db"

# 127.0.0.1 = local only (safe default). Use 0.0.0.0 to serve other devices on the network.
HOST = os.environ.get("LIBRARY_HOST", "127.0.0.1")
PORT = int(os.environ.get("LIBRARY_PORT", "8000"))

# Set LIBRARY_COOKIE_SECURE=1 when the site is served over HTTPS.
COOKIE_SECURE = os.environ.get("LIBRARY_COOKIE_SECURE", "0") == "1"
# Set LIBRARY_TRUST_PROXY=1 only when running behind a reverse proxy you control.
TRUST_PROXY = os.environ.get("LIBRARY_TRUST_PROXY", "0") == "1"

SESSION_COOKIE = "lib_session"
SESSION_HOURS = 8                 # admin sessions (short on purpose)
SESSION_HOURS_USER = 24 * 14      # student sessions stay signed in across page refreshes

# First admin account, created by the SERVER on first run if no admin exists yet.
# It never appears in any front-end file. Override with environment variables.
DEFAULT_ADMIN_PASSWORD = "1234567890"
ADMIN_USERNAME = os.environ.get("LIBRARY_ADMIN_USERNAME", "مكتبة مدرسة تونا الجبل الثانوية المشتركة")
ADMIN_PASSWORD = os.environ.get("LIBRARY_ADMIN_PASSWORD", DEFAULT_ADMIN_PASSWORD)
MAX_BODY_BYTES = 64 * 1024

# Visible status values (labels are defined in the front-end).
BOOK_STATUSES = ("required", "available", "closed")
REQUEST_STATUSES = ("new", "reviewing", "ready", "unavailable", "delivered")
COMPLAINT_STATUSES = ("new", "read")
ROLES = ("user", "admin")
