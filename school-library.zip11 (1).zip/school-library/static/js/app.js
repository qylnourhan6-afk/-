import { h, api, setCsrf, toast, BOOK_STATUS, fmtDate, debounce } from './dom.js';

const app = document.getElementById('app');
let user = null;            // the signed-in account (or null); the server decides what it may do
let accountTab = 'signup';  // which form the account page shows when signed out
let settings = { welcome_title: 'أهلاً بك في مكتبة مدرستنا 📚', welcome_subtitle: '', announcement: '', footer_text: '', requests_open: true };

const ICONS = {
  trophy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4zM17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/></svg>',
  books: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H2zM22 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8z"/></svg>',
  pen: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',
  complaint: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2zM12 7v4M12 14h.01"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
};

/* ---------- shared pieces ---------- */
function pageShell(title, subtitle, ...body) {
  return [
    h('section', { class: 'page-head' },
      h('div', { class: 'wrap wide' },
        h('a', { class: 'back', href: '#/' }, '→ الصفحة الرئيسية'),
        h('h1', {}, title),
        subtitle && h('p', {}, subtitle))),
    h('section', { class: 'wrap wide page-body' }, ...body),
  ];
}

function show(nodes) {
  app.replaceChildren(...[].concat(nodes));
  window.scrollTo(0, 0);
}

const loading = () => h('p', { class: 'loading' }, 'جارٍ التحميل…');
const errorBox = (msg) => h('div', { class: 'empty' }, h('span', { class: 'big' }, '⚠️'), msg);

function fact(label, value) {
  if (!value) return null;
  return h('div', { class: 'fact' }, h('b', {}, label), h('span', {}, value));
}

/* ---------- Home ---------- */
function tile(href, icon, name) {
  return h('a', { class: 'tile', href },
    h('span', { class: 'tile-icon', svg: ICONS[icon] }),
    h('span', { class: 'tile-name' }, name));
}

function renderHome() {
  show([
    h('section', { class: 'hero' },
      h('h1', {}, settings.welcome_title),
      h('div', { class: 'rule' }),
      settings.welcome_subtitle && h('p', {}, settings.welcome_subtitle)),
    h('div', { class: 'wrap' },
      settings.announcement && h('div', { class: 'announce', role: 'status' }, settings.announcement),
      h('nav', { class: 'tiles', 'aria-label': 'أقسام المكتبة' },
        tile('#/competitions', 'trophy', 'مسابقات المكتبة'),
        tile('#/books', 'books', 'الكتب'),
        tile('#/request', 'pen', 'اطلب كتابك اللي ناقص'),
        tile('#/complaints', 'complaint', 'المشاكل اللي شايفها في المدرسة'))),
  ]);
}

/* ---------- Competitions ---------- */
async function renderCompetitions() {
  const list = h('div', { class: 'stack' }, loading());
  show(pageShell('مسابقات المكتبة', 'تعرّف على المسابقات وشروطها ومواعيدها وطريقة المشاركة', list));
  try {
    const { items } = await api('GET', '/api/competitions');
    if (!items.length) {
      list.replaceChildren(h('div', { class: 'empty' }, h('span', { class: 'big' }, '🏆'), 'لا توجد مسابقات معلنة حالياً. تابعنا قريباً.'));
      return;
    }
    list.replaceChildren(...items.map((c) =>
      h('article', { class: 'card' },
        h('h2', {}, c.title),
        c.description && h('p', { class: 'desc' }, c.description),
        h('div', { class: 'facts' },
          fact('شروط الاشتراك', c.conditions),
          fact('موعد المسابقة', [fmtDate(c.event_date), c.event_note].filter(Boolean).join(' — ')),
          fact('طريقة المشاركة', c.how_to_join)))));
  } catch (e) {
    list.replaceChildren(errorBox(e.message));
  }
}

/* ---------- Required books ---------- */
async function renderBooks() {
  const list = h('div', { class: 'stack' }, loading());
  const input = h('input', { type: 'search', placeholder: 'ابحث عن كتاب بالاسم أو المؤلف…', 'aria-label': 'بحث عن كتاب', autocomplete: 'off', maxlength: 100 });
  show(pageShell('الكتب', 'الكتب التي تطلب إدارة المكتبة من الطلاب قراءتها أو توفيرها',
    h('div', { class: 'search' }, input), list));

  let seq = 0;
  async function load() {
    const mine = ++seq;
    try {
      const { items } = await api('GET', '/api/books?q=' + encodeURIComponent(input.value.trim()));
      if (mine !== seq) return;
      if (!items.length) {
        list.replaceChildren(h('div', { class: 'empty' }, h('span', { class: 'big' }, '📖'),
          input.value.trim() ? 'لم يتم العثور على كتاب بهذا الاسم.' : 'لا توجد كتب مطلوبة حالياً.'));
        return;
      }
      list.replaceChildren(...items.map((b) =>
        h('article', { class: 'card' },
          h('div', { class: 'book-top' },
            h('div', {}, h('h2', {}, b.title), b.author && h('p', { class: 'author' }, 'تأليف: ' + b.author)),
            h('span', { class: `badge ${b.status}` }, BOOK_STATUS[b.status] || b.status)),
          b.description && h('p', { class: 'desc' }, b.description))));
    } catch (e) {
      if (mine === seq) list.replaceChildren(errorBox(e.message));
    }
  }
  input.addEventListener('input', debounce(load, 250));
  load();
}

/* ---------- Request form ---------- */
function renderRequest() {
  if (!settings.requests_open) {
    show(pageShell('اطلب كتابك اللي ناقص', '', h('div', { class: 'empty' }, h('span', { class: 'big' }, '⏸️'), 'استقبال الطلبات متوقف مؤقتاً. حاول لاحقاً.')));
    return;
  }
  const err = h('p', { class: 'err', role: 'alert' });
  const submit = h('button', { class: 'btn gold', type: 'submit' }, 'إرسال الطلب');
  const f = {
    name: h('input', { id: 'f-name', name: 'student_name', required: true, maxlength: 80, autocomplete: 'name' }),
    klass: h('input', { id: 'f-class', name: 'class_name', required: true, maxlength: 60, placeholder: 'مثال: الصف الأول الثانوي / 1-3' }),
    book: h('input', { id: 'f-book', name: 'book_title', required: true, maxlength: 150 }),
    notes: h('textarea', { id: 'f-notes', name: 'notes', maxlength: 500 }),
    hp: h('input', { name: 'website', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' }),
  };
  const form = h('form', { class: 'card form', novalidate: true },
    h('div', {}, h('label', { for: 'f-name' }, 'اسم الطالب'), f.name),
    h('div', {}, h('label', { for: 'f-class' }, 'الفصل الدراسي'), f.klass),
    h('div', {}, h('label', { for: 'f-book' }, 'اسم الكتاب الذي تحتاجه'), f.book),
    h('div', {}, h('label', { for: 'f-notes' }, 'ملاحظات إضافية ', h('small', {}, '(اختياري)')), f.notes),
    h('div', { class: 'hp', 'aria-hidden': 'true' }, h('label', {}, 'اترك هذا الحقل فارغاً'), f.hp),
    err, submit);

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    err.textContent = '';
    const body = {
      student_name: f.name.value, class_name: f.klass.value, book_title: f.book.value,
      notes: f.notes.value, website: f.hp.value,
    };
    if (!body.student_name.trim() || !body.class_name.trim() || !body.book_title.trim()) {
      err.textContent = 'الرجاء تعبئة الاسم والفصل واسم الكتاب';
      return;
    }
    submit.disabled = true;
    try {
      await api('POST', '/api/requests', body);
      show(pageShell('تم استلام طلبك', '',
        h('div', { class: 'card success' },
          h('div', { class: 'check', svg: ICONS.check }),
          h('h2', {}, 'تم إرسال طلبك بنجاح'),
          h('p', {}, `شكراً ${body.student_name.trim()}، سيطّلع أمين المكتبة على طلبك للكتاب «${body.book_title.trim()}».`),
          h('div', { class: 'row' },
            h('a', { class: 'btn', href: '#/' }, 'العودة للرئيسية'),
            h('a', { class: 'btn ghost', href: '#/request', onclick: () => setTimeout(route) }, 'طلب كتاب آخر')))));
    } catch (e) {
      err.textContent = e.message;
      submit.disabled = false;
    }
  });
  show(pageShell('اطلب كتابك اللي ناقص', 'اكتب اسم الكتاب الذي تحتاجه وسيصل طلبك إلى أمين المكتبة', form));
}

/* ---------- Account (sign up / login / profile) ---------- */
const NAME_RE = /^[\p{L}\p{M} '’-]{2,30}$/u;
const USERNAME_RE = /^[\p{L}\p{N}_.-]{3,30}$/u;

function setUser(u, csrf) {
  user = u;
  setCsrf(u ? csrf : '');
}

function labeled(id, label, input, hint) {
  return h('div', {}, h('label', { for: id }, label), input, hint && h('p', { class: 'hint' }, hint));
}

function validateSignup(v) {
  if (!NAME_RE.test(v.first_name.trim())) return 'الاسم الأول: حروف فقط (من 2 إلى 30 حرفاً)';
  if (!NAME_RE.test(v.second_name.trim())) return 'الاسم الثاني: حروف فقط (من 2 إلى 30 حرفاً)';
  if (!NAME_RE.test(v.third_name.trim())) return 'الاسم الثالث: حروف فقط (من 2 إلى 30 حرفاً)';
  if (!USERNAME_RE.test(v.username.trim())) return 'اسم المستخدم من 3 إلى 30 حرفاً: حروف وأرقام و ( . _ - ) فقط وبدون مسافات';
  if (v.password.length < 8) return 'كلمة المرور يجب ألا تقل عن 8 أحرف';
  if (v.password !== v.confirm_password) return 'تأكيد كلمة المرور غير مطابق';
  return '';
}

function signupForm() {
  const err = h('p', { class: 'err', role: 'alert' });
  const submit = h('button', { class: 'btn gold', type: 'submit' }, 'إنشاء الحساب');
  const f = {
    first_name: h('input', { id: 'su-first', required: true, maxlength: 30, autocomplete: 'given-name' }),
    second_name: h('input', { id: 'su-second', required: true, maxlength: 30, autocomplete: 'additional-name' }),
    third_name: h('input', { id: 'su-third', required: true, maxlength: 30, autocomplete: 'family-name' }),
    username: h('input', { id: 'su-user', required: true, maxlength: 30, autocomplete: 'username', autocapitalize: 'none', dir: 'ltr' }),
    password: h('input', { id: 'su-pass', type: 'password', required: true, maxlength: 128, autocomplete: 'new-password' }),
    confirm_password: h('input', { id: 'su-pass2', type: 'password', required: true, maxlength: 128, autocomplete: 'new-password' }),
  };
  const form = h('form', { class: 'card form', novalidate: true },
    h('div', { class: 'row2' }, labeled('su-first', 'الاسم الأول', f.first_name), labeled('su-second', 'الاسم الثاني', f.second_name)),
    labeled('su-third', 'الاسم الثالث', f.third_name),
    labeled('su-user', 'اسم المستخدم', f.username, 'ستستخدمه لتسجيل الدخول: حروف وأرقام بدون مسافات'),
    labeled('su-pass', 'كلمة المرور', f.password, '8 أحرف على الأقل'),
    labeled('su-pass2', 'تأكيد كلمة المرور', f.confirm_password),
    err, submit);
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    err.textContent = '';
    const body = Object.fromEntries(Object.entries(f).map(([k, el]) => [k, el.value]));
    const problem = validateSignup(body);
    if (problem) { err.textContent = problem; return; }
    submit.disabled = true;
    try {
      const r = await api('POST', '/api/signup', body);
      setUser(r.user, r.csrf);
      toast('تم إنشاء حسابك بنجاح، أهلاً بك ' + r.user.first_name);
      renderAccount();
    } catch (e) {
      err.textContent = e.message;
      submit.disabled = false;
    }
  });
  return form;
}

function loginForm() {
  const err = h('p', { class: 'err', role: 'alert' });
  const submit = h('button', { class: 'btn', type: 'submit' }, 'تسجيل الدخول');
  const username = h('input', { id: 'li-user', required: true, maxlength: 64, autocomplete: 'username', autocapitalize: 'none', dir: 'ltr' });
  const password = h('input', { id: 'li-pass', type: 'password', required: true, maxlength: 256, autocomplete: 'current-password' });
  const form = h('form', { class: 'card form', novalidate: true },
    labeled('li-user', 'اسم المستخدم', username),
    labeled('li-pass', 'كلمة المرور', password),
    err, submit);
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    err.textContent = '';
    if (!username.value.trim() || !password.value) { err.textContent = 'الرجاء إدخال اسم المستخدم وكلمة المرور'; return; }
    submit.disabled = true;
    try {
      const r = await api('POST', '/api/login', { username: username.value, password: password.value });
      if (r.user.role === 'admin') {   // the server decides the role; admins go to their dashboard
        location.href = '/admin/';
        return;
      }
      setUser(r.user, r.csrf);
      toast('أهلاً بعودتك ' + r.user.first_name);
      renderAccount();
    } catch (e) {
      err.textContent = e.message;
      password.value = '';
      submit.disabled = false;
    }
  });
  return form;
}

function profileCard() {
  const logoutBtn = h('button', { class: 'btn ghost', type: 'button' }, 'تسجيل الخروج');
  logoutBtn.addEventListener('click', async () => {
    logoutBtn.disabled = true;
    try { await api('POST', '/api/logout', {}); } catch { /* session may already be gone */ }
    setUser(null);
    toast('تم تسجيل الخروج');
    renderAccount();
  });
  return h('div', { class: 'card profile' },
    h('div', { class: 'avatar', 'aria-hidden': 'true' }, [...user.first_name][0]),
    h('h2', {}, user.full_name),
    h('p', { class: 'author' }, '@' + user.username),
    h('span', { class: `badge ${user.role === 'admin' ? 'required' : 'available'}` }, user.role === 'admin' ? 'حساب إدارة' : 'حساب طالب'),
    h('div', { class: 'actions-col' },
      user.role === 'admin' && h('a', { class: 'btn gold', href: '/admin/' }, 'فتح لوحة الإدارة'),
      logoutBtn));
}

function renderAccount() {
  if (user) {
    show(pageShell('حسابك', 'أنت مسجّل الدخول', profileCard()));
    return;
  }
  const holder = h('div');
  const tabs = h('div', { class: 'seg', role: 'tablist' });
  const draw = () => {
    tabs.replaceChildren(...[['signup', 'إنشاء حساب'], ['login', 'تسجيل دخول']].map(([id, label]) =>
      h('button', {
        type: 'button', role: 'tab', 'aria-selected': String(accountTab === id),
        onclick: () => { accountTab = id; draw(); },
      }, label)));
    holder.replaceChildren(accountTab === 'signup' ? signupForm() : loginForm());
  };
  draw();
  show(pageShell('حسابك', 'أنشئ حساباً جديداً أو سجّل دخولك', tabs, holder));
}

/* ---------- Anonymous complaints box ---------- */
function renderComplaints() {
  const err = h('p', { class: 'err', role: 'alert' });
  const submit = h('button', { class: 'btn gold', type: 'submit' }, 'إرسال الرسالة');
  const msg = h('textarea', { id: 'c-msg', rows: 6, maxlength: 1500, required: true, placeholder: 'اكتب هنا ما يضايقك أو ما تتمنى أن يتحسّن…' });
  const counter = h('small', { class: 'counter' }, '0 / 1500');
  const hp = h('input', { name: 'website', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' });
  msg.addEventListener('input', () => { counter.textContent = `${msg.value.length} / 1500`; });
  const form = h('form', { class: 'card form', novalidate: true },
    h('div', {}, h('div', { class: 'label-row' }, h('label', { for: 'c-msg' }, 'المشاكل اللي شايفها في المدرسة؟'), counter), msg),
    h('div', { class: 'hp', 'aria-hidden': 'true' }, h('label', {}, 'اترك هذا الحقل فارغاً'), hp),
    err, submit);
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    err.textContent = '';
    if (msg.value.trim().length < 5) { err.textContent = 'اكتب رسالة لا تقل عن 5 أحرف'; return; }
    submit.disabled = true;
    try {
      await api('POST', '/api/complaints', { message: msg.value, website: hp.value });
      show(pageShell('وصلت رسالتك', '',
        h('div', { class: 'card success' },
          h('div', { class: 'check', svg: ICONS.check }),
          h('h2', {}, 'شكراً لصراحتك'),
          h('p', {}, 'وصلت رسالتك إلى الإدارة بدون اسمك أو أي معلومة عنك.'),
          h('div', { class: 'row' },
            h('a', { class: 'btn', href: '#/' }, 'العودة للرئيسية'),
            h('a', { class: 'btn ghost', href: '#/complaints', onclick: () => setTimeout(route) }, 'إرسال رسالة أخرى')))));
    } catch (e) {
      err.textContent = e.message;
      submit.disabled = false;
    }
  });
  show(pageShell('المشاكل اللي شايفها في المدرسة', 'قل لنا بصراحة ما يضايقك لنعمل على تحسينه',
    h('div', { class: 'privacy', role: 'note' },
      h('span', { class: 'lock', 'aria-hidden': 'true' }, '🔒'),
      h('p', {}, 'رسالتك مجهولة تماماً: لا نطلب اسمك ولا نحفظ حسابك أو أي معلومة تدل عليك، ولن تظهر هويتك للإدارة. وإن أردت إخفاء هويتك فلا تكتب اسمك داخل الرسالة.')),
    form));
}

/* ---------- Router ---------- */
const ROUTES = {
  '': renderHome, '/': renderHome,
  '/competitions': renderCompetitions, '/books': renderBooks, '/request': renderRequest,
  '/complaints': renderComplaints, '/account': renderAccount,
};
const TITLES = {
  '/competitions': 'مسابقات المكتبة', '/books': 'الكتب', '/request': 'اطلب كتابك اللي ناقص',
  '/complaints': 'المشاكل اللي شايفها في المدرسة', '/account': 'حسابك',
};

function markNav(path) {
  document.querySelectorAll('[data-nav]').forEach((a) => {
    const on = (a.dataset.nav === 'account') === (path === '/account');
    a.classList.toggle('active', on);
    if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
}

function route() {
  const path = location.hash.replace(/^#/, '');
  (ROUTES[path] || renderHome)();
  document.title = TITLES[path] ? `${TITLES[path]} — مكتبة مدرستنا` : 'مكتبة مدرستنا';
  markNav(ROUTES[path] ? path : '/');
}

async function start() {
  try {
    settings = { ...settings, ...(await api('GET', '/api/settings')) };
  } catch { /* fall back to defaults */ }
  try {
    const me = await api('GET', '/api/me');   // keeps the session across page refreshes
    if (me.user) setUser(me.user, me.csrf);
  } catch { /* stay signed out */ }
  if (settings.footer_text) document.getElementById('footer-text').textContent = settings.footer_text;
  window.addEventListener('hashchange', route);
  route();
}
start();
