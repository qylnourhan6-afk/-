import { h, api, setCsrf, toast, debounce, fmtDate, fmtDateTime, REQUEST_STATUS, BOOK_STATUS } from '/js/dom.js';

const root = document.getElementById('root');
let me = null;
let meId = null;   // id of the signed-in admin (an admin cannot edit their own row)
let activeTab = 'requests';

/* ---------- boot ---------- */
async function boot() {
  try {
    const r = await api('GET', '/api/admin/me');
    setCsrf(r.csrf);
    me = r.username;
    meId = r.id;
    renderDashboard();
  } catch {
    renderLogin();
  }
}

/* ---------- login ---------- */
function renderLogin() {
  const err = h('p', { class: 'err', role: 'alert' });
  const user = h('input', { id: 'u', autocomplete: 'username', required: true, maxlength: 64 });
  const pass = h('input', { id: 'p', type: 'password', autocomplete: 'current-password', required: true, maxlength: 256 });
  const btn = h('button', { class: 'btn', type: 'submit' }, 'تسجيل الدخول');
  const form = h('form', { class: 'card form login-card' },
    h('h1', {}, 'لوحة إدارة المكتبة'),
    h('p', { class: 'sub' }, 'خاصة بأمين المكتبة'),
    h('div', {}, h('label', { for: 'u' }, 'اسم المستخدم'), user),
    h('div', {}, h('label', { for: 'p' }, 'كلمة المرور'), pass),
    err, btn,
    h('a', { class: 'back', href: '/' }, '→ العودة إلى الموقع'));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    btn.disabled = true;
    try {
      const r = await api('POST', '/api/admin/login', { username: user.value, password: pass.value });
      setCsrf(r.csrf);
      me = r.username;
      meId = r.user.id;
      renderDashboard();
    } catch (ex) {
      err.textContent = ex.message;
      btn.disabled = false;
      pass.value = '';
    }
  });
  root.replaceChildren(h('div', { class: 'login-wrap' }, form));
  user.focus();
}

/* ---------- shell ---------- */
const BADGE = { requests: 'new-count', complaints: 'new-complaints' };
const TABS = [
  ['requests', 'طلبات الكتب'],
  ['users', 'المستخدمون'],
  ['complaints', 'ما يضايق الطلاب'],
  ['competitions', 'المسابقات'],
  ['books', 'الكتب المطلوبة'],
  ['settings', 'محتوى الموقع'],
  ['account', 'الحساب'],
];

async function renderDashboard() {
  const panel = h('div', { class: 'a-main' });
  const tabs = h('div', { class: 'a-tabs', role: 'tablist' }, TABS.map(([id, label]) =>
    h('button', {
      class: 'a-tab', role: 'tab', id: `tab-${id}`, 'aria-selected': String(id === activeTab),
      onclick: () => { activeTab = id; renderDashboard(); },
    }, label, BADGE[id] && h('span', { class: 'n', id: BADGE[id], hidden: true }))));
  const logout = h('button', {
    class: 'btn sm ghost logout',
    onclick: async () => { try { await api('POST', '/api/admin/logout', {}); } catch { /* ignore */ } me = null; renderLogin(); },
  }, 'تسجيل الخروج');

  root.replaceChildren(
    h('header', { class: 'a-bar' },
      h('b', {}, '📚 لوحة إدارة المكتبة'),
      h('div', { class: 'who' }, h('span', {}, `مرحباً، ${me}`), h('a', { class: 'admin-link', href: '/' }, 'عرض الموقع'), logout)),
    tabs, panel);

  api('GET', '/api/admin/stats').then((s) => {
    for (const [key, id] of [['new_requests', 'new-count'], ['new_complaints', 'new-complaints']]) {
      const n = document.getElementById(id);
      if (n && s[key]) { n.textContent = s[key]; n.hidden = false; }
    }
  }).catch(() => {});

  const views = { requests: viewRequests, users: viewUsers, complaints: viewComplaints, competitions: viewCompetitions, books: viewBooks, settings: viewSettings, account: viewAccount };
  try {
    await views[activeTab](panel);
  } catch (e) {
    handleError(e);
  }
}

function handleError(e) {
  if (e.status === 401) { me = null; renderLogin(); return; }
  toast(e.message, 'bad');
}

/* ---------- generic modal form ---------- */
function openForm({ title, fields, values = {}, submitLabel = 'حفظ', onSubmit }) {
  const dlg = h('dialog');
  const err = h('p', { class: 'err', role: 'alert' });
  const inputs = {};
  const rows = fields.map((f) => {
    const id = `m-${f.name}`;
    let input;
    const val = values[f.name] ?? f.default ?? '';
    if (f.type === 'textarea') input = h('textarea', { id, maxlength: f.max, value: val });
    else if (f.type === 'select') input = h('select', { id }, Object.entries(f.options).map(([k, v]) => h('option', { value: k, selected: k === val }, v)));
    else if (f.type === 'checkbox') input = h('input', { id, type: 'checkbox', checked: val === '' ? true : !!val });
    else input = h('input', { id, type: f.type || 'text', maxlength: f.max, value: val });
    inputs[f.name] = input;
    if (f.type === 'checkbox') return h('div', { class: 'check-row' }, input, h('label', { for: id }, f.label));
    return h('div', {}, h('label', { for: id }, f.label, f.optional && h('small', {}, ' (اختياري)')), input);
  });
  const save = h('button', { class: 'btn', type: 'submit' }, submitLabel);
  const cancel = h('button', { class: 'btn ghost', type: 'button', onclick: () => dlg.close() }, 'إلغاء');
  const form = h('form', { novalidate: true }, h('h2', {}, title), rows, err, h('div', { class: 'actions' }, save, cancel));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    const data = {};
    for (const f of fields) data[f.name] = f.type === 'checkbox' ? inputs[f.name].checked : inputs[f.name].value;
    save.disabled = true;
    try {
      await onSubmit(data);
      dlg.close();
    } catch (ex) {
      if (ex.status === 401) { dlg.close(); handleError(ex); return; }
      err.textContent = ex.message;
      save.disabled = false;
    }
  });
  dlg.append(form);
  dlg.addEventListener('close', () => dlg.remove());
  document.body.append(dlg);
  dlg.showModal();
}

const confirmDelete = (what) => window.confirm(`هل أنت متأكد من حذف ${what}؟ لا يمكن التراجع عن ذلك.`);

/* ---------- requests ---------- */
async function viewRequests(panel) {
  let status = '';
  const search = h('input', { type: 'search', placeholder: 'ابحث باسم الطالب أو الفصل أو الكتاب…', 'aria-label': 'بحث في الطلبات', maxlength: 100 });
  const chips = h('div', { class: 'chips' });
  const list = h('div', { class: 'stack' });
  panel.append(h('h2', { class: 'a-title' }, 'طلبات الكتب من الطلاب'), h('div', { class: 'a-tools' }, search), chips, list);

  async function load() {
    const qs = new URLSearchParams();
    if (search.value.trim()) qs.set('q', search.value.trim());
    if (status) qs.set('status', status);
    const data = await api('GET', '/api/admin/requests?' + qs);
    const total = Object.values(data.counts).reduce((a, b) => a + b, 0);
    chips.replaceChildren(
      chip('', `الكل (${total})`),
      ...Object.entries(REQUEST_STATUS).map(([k, v]) => chip(k, `${v} (${data.counts[k] || 0})`)));
    if (!data.items.length) {
      list.replaceChildren(h('div', { class: 'empty' }, h('span', { class: 'big' }, '📭'), 'لا توجد طلبات مطابقة.'));
      return;
    }
    list.replaceChildren(...data.items.map(requestCard));
  }
  const reload = () => load().catch(handleError);

  function chip(value, label) {
    return h('button', { class: 'chip', 'aria-pressed': String(status === value), onclick: () => { status = value; reload(); } }, label);
  }

  function requestCard(r) {
    const select = h('select', { 'aria-label': 'حالة الطلب' },
      Object.entries(REQUEST_STATUS).map(([k, v]) => h('option', { value: k, selected: k === r.status }, v)));
    select.addEventListener('change', async () => {
      try {
        await api('PATCH', `/api/admin/requests/${r.id}`, { status: select.value });
        toast('تم تحديث حالة الطلب');
        reload();
      } catch (e) { handleError(e); select.value = r.status; }
    });
    const note = h('textarea', { placeholder: 'ملاحظة للأمين (لا تظهر للطلاب)', maxlength: 500, 'aria-label': 'ملاحظة', value: r.admin_note });
    return h('article', { class: 'card item' },
      h('div', { class: 'item-head' },
        h('div', {}, h('h3', {}, r.book_title), h('p', { class: 'meta' }, `${r.student_name} — ${r.class_name}`)),
        h('span', { class: `badge ${r.status}` }, REQUEST_STATUS[r.status])),
      r.notes && h('p', { class: 'desc' }, 'ملاحظات الطالب: ' + r.notes),
      h('p', { class: 'meta' }, 'وصل في ' + fmtDateTime(r.created_at)),
      h('div', { class: 'note-row' }, note),
      h('div', { class: 'actions' },
        select,
        h('button', { class: 'btn sm', onclick: async () => {
          try { await api('PATCH', `/api/admin/requests/${r.id}`, { admin_note: note.value }); toast('تم حفظ الملاحظة'); } catch (e) { handleError(e); }
        } }, 'حفظ الملاحظة'),
        h('button', { class: 'btn sm danger', onclick: async () => {
          if (!confirmDelete('هذا الطلب')) return;
          try { await api('DELETE', `/api/admin/requests/${r.id}`); toast('تم حذف الطلب'); reload(); } catch (e) { handleError(e); }
        } }, 'حذف')));
  }

  search.addEventListener('input', debounce(reload, 250));
  await load();
}

/* ---------- competitions ---------- */
const COMP_FIELDS = [
  { name: 'title', label: 'اسم المسابقة', max: 150 },
  { name: 'description', label: 'وصف المسابقة', type: 'textarea', max: 1500, optional: true },
  { name: 'conditions', label: 'شروط الاشتراك', type: 'textarea', max: 1500, optional: true },
  { name: 'event_date', label: 'تاريخ المسابقة', type: 'date', optional: true },
  { name: 'event_note', label: 'ملاحظة على الموعد (مثل: الساعة 10 صباحاً في المكتبة)', max: 150, optional: true },
  { name: 'how_to_join', label: 'طريقة المشاركة', type: 'textarea', max: 1500, optional: true },
  { name: 'is_active', label: 'ظاهرة للطلاب', type: 'checkbox' },
];

async function viewCompetitions(panel) {
  const list = h('div', { class: 'stack' });
  panel.append(
    h('h2', { class: 'a-title' }, 'المسابقات'),
    h('div', { class: 'a-tools' }, h('button', { class: 'btn gold', onclick: () => edit(null) }, '＋ إضافة مسابقة')),
    list);

  async function load() {
    const { items } = await api('GET', '/api/admin/competitions');
    if (!items.length) {
      list.replaceChildren(h('div', { class: 'empty' }, h('span', { class: 'big' }, '🏆'), 'لم تتم إضافة أي مسابقة بعد.'));
      return;
    }
    list.replaceChildren(...items.map((c) =>
      h('article', { class: 'card item' },
        h('div', { class: 'item-head' },
          h('div', { class: c.is_active ? '' : 'off' }, h('h3', {}, c.title),
            h('p', { class: 'meta' }, [c.event_date && fmtDate(c.event_date), c.event_note].filter(Boolean).join(' — ') || 'بدون موعد')),
          h('span', { class: `badge ${c.is_active ? 'available' : 'closed'}` }, c.is_active ? 'ظاهرة' : 'مخفية')),
        h('div', { class: 'actions' },
          h('button', { class: 'btn sm', onclick: () => edit(c) }, 'تعديل'),
          h('button', { class: 'btn sm danger', onclick: async () => {
            if (!confirmDelete(`المسابقة «${c.title}»`)) return;
            try { await api('DELETE', `/api/admin/competitions/${c.id}`); toast('تم الحذف'); load(); } catch (e) { handleError(e); }
          } }, 'حذف')))));
  }

  function edit(c) {
    openForm({
      title: c ? 'تعديل المسابقة' : 'إضافة مسابقة',
      fields: COMP_FIELDS,
      values: c || {},
      onSubmit: async (data) => {
        if (c) await api('PUT', `/api/admin/competitions/${c.id}`, data);
        else await api('POST', '/api/admin/competitions', data);
        toast('تم الحفظ');
        load().catch(handleError);
      },
    });
  }
  await load();
}

/* ---------- books ---------- */
const BOOK_FIELDS = [
  { name: 'title', label: 'اسم الكتاب', max: 200 },
  { name: 'author', label: 'اسم المؤلف', max: 120, optional: true },
  { name: 'description', label: 'وصف مختصر', type: 'textarea', max: 1000, optional: true },
  { name: 'status', label: 'حالة الكتاب', type: 'select', options: BOOK_STATUS, default: 'required' },
];

async function viewBooks(panel) {
  const search = h('input', { type: 'search', placeholder: 'ابحث عن كتاب…', 'aria-label': 'بحث', maxlength: 100 });
  const list = h('div', { class: 'stack' });
  panel.append(
    h('h2', { class: 'a-title' }, 'الكتب المطلوبة'),
    h('div', { class: 'a-tools' }, search, h('button', { class: 'btn gold', onclick: () => edit(null) }, '＋ إضافة كتاب')),
    list);

  async function load() {
    const { items } = await api('GET', '/api/admin/books?q=' + encodeURIComponent(search.value.trim()));
    if (!items.length) {
      list.replaceChildren(h('div', { class: 'empty' }, h('span', { class: 'big' }, '📚'),
        search.value.trim() ? 'لا توجد نتائج.' : 'لم تتم إضافة أي كتاب بعد.'));
      return;
    }
    list.replaceChildren(...items.map((b) =>
      h('article', { class: 'card item' },
        h('div', { class: 'item-head' },
          h('div', {}, h('h3', {}, b.title), b.author && h('p', { class: 'meta' }, b.author)),
          h('span', { class: `badge ${b.status}` }, BOOK_STATUS[b.status])),
        h('div', { class: 'actions' },
          h('button', { class: 'btn sm', onclick: () => edit(b) }, 'تعديل'),
          h('button', { class: 'btn sm danger', onclick: async () => {
            if (!confirmDelete(`الكتاب «${b.title}»`)) return;
            try { await api('DELETE', `/api/admin/books/${b.id}`); toast('تم الحذف'); load(); } catch (e) { handleError(e); }
          } }, 'حذف')))));
  }

  function edit(b) {
    openForm({
      title: b ? 'تعديل الكتاب' : 'إضافة كتاب',
      fields: BOOK_FIELDS,
      values: b || {},
      onSubmit: async (data) => {
        if (b) await api('PUT', `/api/admin/books/${b.id}`, data);
        else await api('POST', '/api/admin/books', data);
        toast('تم الحفظ');
        load().catch(handleError);
      },
    });
  }
  search.addEventListener('input', debounce(() => load().catch(handleError), 250));
  await load();
}

/* ---------- users ---------- */
async function viewUsers(panel) {
  let filter = '';
  const title = h('h2', { class: 'a-title' }, 'المستخدمون المسجّلون');
  const search = h('input', { type: 'search', placeholder: 'ابحث بالاسم أو اسم المستخدم…', 'aria-label': 'بحث في المستخدمين', maxlength: 100 });
  const chips = h('div', { class: 'chips' });
  const list = h('div', { class: 'stack' });
  panel.append(title, h('div', { class: 'a-tools' }, search), chips, list);

  const reload = () => load().catch(handleError);
  const chip = (value, label) =>
    h('button', { class: 'chip', 'aria-pressed': String(filter === value), onclick: () => { filter = value; reload(); } }, label);

  async function act(fn, okMsg) {
    try { await fn(); toast(okMsg); reload(); } catch (e) { handleError(e); }
  }

  function userCard(u) {
    const mine = u.id === meId;
    const patch = (body) => api('PATCH', `/api/admin/users/${u.id}`, body);
    const actions = mine ? null : h('div', { class: 'actions' },
      h('button', { class: 'btn sm', onclick: () => {
        if (u.is_active && !window.confirm(`تعطيل حساب «${u.full_name}»؟ سيتم تسجيل خروجه ولن يستطيع الدخول.`)) return;
        act(() => patch({ is_active: !u.is_active }), u.is_active ? 'تم تعطيل الحساب' : 'تم تفعيل الحساب');
      } }, u.is_active ? 'تعطيل الحساب' : 'تفعيل الحساب'),
      h('button', { class: 'btn sm ghost', onclick: () => {
        const toAdmin = u.role !== 'admin';
        if (toAdmin && !window.confirm(`منح «${u.full_name}» صلاحيات الإدارة الكاملة؟`)) return;
        act(() => patch({ role: toAdmin ? 'admin' : 'user' }), toAdmin ? 'تمت الترقية إلى إدارة' : 'تم التحويل إلى حساب طالب');
      } }, u.role === 'admin' ? 'تحويل إلى طالب' : 'ترقية إلى إدارة'),
      h('button', { class: 'btn sm ghost', onclick: () => openForm({
        title: `كلمة مرور جديدة لـ ${u.full_name}`,
        fields: [{ name: 'new_password', label: 'كلمة المرور الجديدة (8 أحرف على الأقل)', type: 'password', max: 128 }],
        submitLabel: 'تعيين كلمة المرور',
        onSubmit: async (d) => { await patch({ new_password: d.new_password }); toast('تم تعيين كلمة المرور وتسجيل خروج صاحب الحساب'); },
      }) }, 'كلمة مرور جديدة'),
      h('button', { class: 'btn sm danger', onclick: () => {
        if (!confirmDelete(`حساب «${u.full_name}»`)) return;
        act(() => api('DELETE', `/api/admin/users/${u.id}`), 'تم حذف الحساب');
      } }, 'حذف'));
    return h('article', { class: 'card item' },
      h('div', { class: 'item-head' },
        h('div', { class: u.is_active ? '' : 'off' }, h('h3', {}, u.full_name), h('p', { class: 'meta', dir: 'ltr' }, '@' + u.username)),
        h('div', { class: 'actions' },
          h('span', { class: `badge ${u.role === 'admin' ? 'required' : 'reviewing'}` }, u.role === 'admin' ? 'إدارة' : 'طالب'),
          h('span', { class: `badge ${u.is_active ? 'available' : 'closed'}` }, u.is_active ? 'نشط' : 'معطّل'),
          mine && h('span', { class: 'badge' }, 'حسابك'))),
      h('p', { class: 'meta' }, `انضم في ${fmtDateTime(u.created_at)} — آخر دخول: ${u.last_login ? fmtDateTime(u.last_login) : 'لم يدخل بعد'}`),
      actions);
  }

  async function load() {
    const qs = new URLSearchParams();
    if (search.value.trim()) qs.set('q', search.value.trim());
    if (filter) qs.set('filter', filter);
    const { items, counts: c } = await api('GET', '/api/admin/users?' + qs);
    title.textContent = `المستخدمون المسجّلون (${c.total})`;
    chips.replaceChildren(chip('', `الكل (${c.total})`), chip('active', `نشط (${c.active})`),
      chip('disabled', `معطّل (${c.disabled})`), chip('admin', `إدارة (${c.admins})`));
    list.replaceChildren(...(items.length
      ? items.map(userCard)
      : [h('div', { class: 'empty' }, h('span', { class: 'big' }, '👥'), 'لا يوجد مستخدمون مطابقون.')]));
  }
  search.addEventListener('input', debounce(reload, 250));
  await load();
}

/* ---------- anonymous complaints ---------- */
const COMPLAINT_STATUS = { new: 'جديدة', read: 'تمت القراءة' };

async function viewComplaints(panel) {
  let status = '';
  const chips = h('div', { class: 'chips' });
  const list = h('div', { class: 'stack' });
  panel.append(
    h('h2', { class: 'a-title' }, 'ما يضايق الطلاب في المدرسة'),
    h('div', { class: 'privacy', role: 'note' }, h('span', { class: 'lock', 'aria-hidden': 'true' }, '🔒'),
      h('p', {}, 'هذه الرسائل مجهولة: لا يتم حفظ اسم الكاتب ولا حسابه ولا أي معلومة عنه، لذلك لا يمكن معرفة من أرسلها.')),
    chips, list);

  const reload = () => load().catch(handleError);
  const chip = (value, label) =>
    h('button', { class: 'chip', 'aria-pressed': String(status === value), onclick: () => { status = value; reload(); } }, label);

  async function load() {
    const { items, counts } = await api('GET', '/api/admin/complaints' + (status ? `?status=${status}` : ''));
    chips.replaceChildren(chip('', `الكل (${counts.new + counts.read})`),
      chip('new', `جديدة (${counts.new})`), chip('read', `تمت القراءة (${counts.read})`));
    if (!items.length) {
      list.replaceChildren(h('div', { class: 'empty' }, h('span', { class: 'big' }, '📭'), 'لا توجد رسائل.'));
      return;
    }
    list.replaceChildren(...items.map((c) =>
      h('article', { class: 'card item' },
        h('div', { class: 'item-head' },
          h('p', { class: 'meta' }, fmtDate(c.created_on)),
          h('span', { class: `badge ${c.status === 'new' ? 'new' : 'delivered'}` }, COMPLAINT_STATUS[c.status])),
        h('p', { class: 'desc' }, c.message),
        h('div', { class: 'actions' },
          h('button', { class: 'btn sm', onclick: async () => {
            try { await api('PATCH', `/api/admin/complaints/${c.id}`, { status: c.status === 'new' ? 'read' : 'new' }); reload(); } catch (e) { handleError(e); }
          } }, c.status === 'new' ? 'تحديد كمقروءة' : 'إرجاع إلى جديدة'),
          h('button', { class: 'btn sm danger', onclick: async () => {
            if (!confirmDelete('هذه الرسالة')) return;
            try { await api('DELETE', `/api/admin/complaints/${c.id}`); toast('تم الحذف'); reload(); } catch (e) { handleError(e); }
          } }, 'حذف'))))); 
  }
  await load();
}

/* ---------- site content ---------- */
async function viewSettings(panel) {
  const s = await api('GET', '/api/settings');
  const err = h('p', { class: 'err', role: 'alert' });
  const el = {
    welcome_title: h('input', { id: 's1', maxlength: 120, value: s.welcome_title }),
    welcome_subtitle: h('input', { id: 's2', maxlength: 200, value: s.welcome_subtitle }),
    announcement: h('input', { id: 's3', maxlength: 300, value: s.announcement, placeholder: 'اتركه فارغاً لإخفاء الإعلان' }),
    footer_text: h('input', { id: 's4', maxlength: 200, value: s.footer_text }),
    requests_open: h('input', { id: 's5', type: 'checkbox', checked: s.requests_open }),
  };
  const form = h('form', { class: 'card form', novalidate: true },
    h('div', {}, h('label', { for: 's1' }, 'عنوان الترحيب'), el.welcome_title),
    h('div', {}, h('label', { for: 's2' }, 'العبارة الترحيبية'), el.welcome_subtitle),
    h('div', {}, h('label', { for: 's3' }, 'إعلان أعلى الصفحة الرئيسية'), el.announcement),
    h('div', {}, h('label', { for: 's4' }, 'نص أسفل الصفحة'), el.footer_text),
    h('div', { class: 'check-row' }, el.requests_open, h('label', { for: 's5' }, 'استقبال طلبات الكتب من الطلاب')),
    err, h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'submit' }, 'حفظ التغييرات')));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    try {
      await api('PUT', '/api/admin/settings', {
        welcome_title: el.welcome_title.value, welcome_subtitle: el.welcome_subtitle.value,
        announcement: el.announcement.value, footer_text: el.footer_text.value,
        requests_open: el.requests_open.checked,
      });
      toast('تم حفظ محتوى الموقع');
    } catch (ex) {
      if (ex.status === 401) return handleError(ex);
      err.textContent = ex.message;
    }
  });
  panel.append(h('h2', { class: 'a-title' }, 'محتوى الموقع'), form);
}

/* ---------- account ---------- */
async function viewAccount(panel) {
  const err = h('p', { class: 'err', role: 'alert' });
  const cur = h('input', { id: 'c1', type: 'password', autocomplete: 'current-password', maxlength: 256 });
  const nw = h('input', { id: 'c2', type: 'password', autocomplete: 'new-password', maxlength: 256 });
  const again = h('input', { id: 'c3', type: 'password', autocomplete: 'new-password', maxlength: 256 });
  const form = h('form', { class: 'card form', novalidate: true },
    h('div', {}, h('label', { for: 'c1' }, 'كلمة المرور الحالية'), cur),
    h('div', {}, h('label', { for: 'c2' }, 'كلمة المرور الجديدة ', h('small', {}, '(8 أحرف على الأقل)')), nw),
    h('div', {}, h('label', { for: 'c3' }, 'تأكيد كلمة المرور الجديدة'), again),
    err, h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'submit' }, 'تغيير كلمة المرور')));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    if (nw.value !== again.value) { err.textContent = 'تأكيد كلمة المرور غير مطابق'; return; }
    try {
      await api('POST', '/api/admin/password', { current: cur.value, new: nw.value });
      toast('تم تغيير كلمة المرور');
      form.reset();
    } catch (ex) {
      if (ex.status === 401) return handleError(ex);
      err.textContent = ex.message;
    }
  });
  panel.append(h('h2', { class: 'a-title' }, 'الحساب'), form);
}

boot();
